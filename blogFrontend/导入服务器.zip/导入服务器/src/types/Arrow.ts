export default interface WisdomProps {
    text1: string;
    text2: string;
    onClick?: () => void;
}