export default interface TyperwriterProps {
    text: string;
    delay?: number;
    className?: string;
    cursorChar?: string;
}