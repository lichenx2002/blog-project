export interface ThoughtsProps {
    id: number;
    content: string;
    mood: string;
    location: string;
    tags: string;
    createdAt: string;
    weather: string;
    device:string;
}