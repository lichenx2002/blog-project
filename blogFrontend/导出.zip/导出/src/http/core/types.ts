export default interface RequestConfig extends RequestInit {
    params?: Record<string, any>;
}

export interface HttpResponse<T> {
    data: T;
    status: number;
    headers: Headers;
}

export interface ErrorResponse {
    message: string;
    status: number;
    url: string;
    meta?: any;
}

export type HeadersInit = Headers | Record<string, string> | Array<[string, string]>;

export type Response = globalThis.Response;