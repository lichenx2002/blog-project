import React from "react";

export default interface AppLayoutProps {
    children: React.ReactNode;
}