// pages/index.tsx
import Home from '@/pages/main/Home';


const IndexPage:React.FC =()=> {
  return(
      <div>
        <Home/>
      </div>);
}// 直接渲染Home组件内容}

export default IndexPage;