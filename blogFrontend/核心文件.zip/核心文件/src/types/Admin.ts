export interface Admin {
    id: number;
    username: string;
}